<?php
	$system = "localhost";
	$usr = "root";
	$pwd = "";
	$db = "accounts";

	$conn = mysqli_connect($system,$usr,$pwd,$db);	
?>